package com.android.foodorderapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class singup extends AppCompatActivity {

    TextView singup;
    EditText inpuid, inppass;
    Button logb;
    ProgressDialog pro;
    FirebaseAuth faut;
    FirebaseUser muser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_singup);
        //getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.black)));
        inpuid = findViewById(R.id.editTextTextPersonName);
        inppass = findViewById(R.id.editTextTextPassword);
        logb = findViewById(R.id.button);
        singup = findViewById(R.id.textView2);
        pro = new ProgressDialog(this);
        faut = FirebaseAuth.getInstance();
        muser = faut.getCurrentUser();
        singup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(singup.this,login.class));
            }
        });
        logb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PerforAuth();
            }
        });
    }

    private void PerforAuth() {
        String id = inpuid.getText().toString();
        String pass = inppass.getText().toString();
        if (id.isEmpty() || id.length() < 3) {
            inppass.setError("Enter Correct email id");
        } else if (pass.isEmpty() || pass.length() < 3) {
            inppass.setError("Enter atleast 6 char");
        } else {
            pro.setMessage("Registaration Successful");
            pro.setCanceledOnTouchOutside(false);
            pro.show();
            faut.createUserWithEmailAndPassword(id,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        pro.dismiss();
                        sendusernext();
                        Toast.makeText(singup.this,"Registaration Successful",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        pro.dismiss();
                        Toast.makeText(singup.this,""+task.getException(),Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }


    }
    private void sendusernext(){
        Intent intent=new Intent(singup.this, login.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK|Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }






}
